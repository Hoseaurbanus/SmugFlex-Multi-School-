<?php
/**
 * CBT Controller (Teacher-owned)
 *
 * Rules:
 * - Exams are anchored to subject_assignments (teacher can only manage their own assignments)
 * - Exams/attempts are locked to current term + academic year from school_settings
 * - Question edits are locked when exam is published
 * - Students get a shuffled subset of questions (default 30) per attempt; selection is persisted via cbt_answers rows
 * - Duration is enforced server-side; when expired, attempt is auto-submitted/scored on next request (heartbeat/save/submit)
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Middleware.php';
require_once __DIR__ . '/../helpers/RealtimeEvents.php';

class CbtController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    private function columnExists(string $table, string $column): bool {
        try {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :t AND COLUMN_NAME = :c");
            $stmt->bindValue(':t', $table);
            $stmt->bindValue(':c', $column);
            $stmt->execute();
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (Throwable $e) {
            return false;
        }
    }

    private function getCurrentSettings(): array {
        $stmt = $this->conn->prepare("SELECT setting_key, setting_value FROM school_settings WHERE setting_key IN ('current_academic_year','current_term')");
        $stmt->execute();
        $settings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        $year = (string)($settings['current_academic_year'] ?? '');
        $term = (string)($settings['current_term'] ?? '');
        if (trim($year) === '' || trim($term) === '') {
            Response::serverError('School settings current term/academic year not configured');
        }
        return ['academic_year' => $year, 'term' => $term];
    }

    private function fetchTeacherSubjectAssignmentForCurrent(int $teacherId, int $subjectAssignmentId, string $term, string $year): array {
        // NOTE: schema varies; we best-effort enforce term/year if columns exist.
        $hasTerm = $this->columnExists('subject_assignments', 'term');
        $hasYear = $this->columnExists('subject_assignments', 'academic_year');

        $where = "WHERE sa.id = :sa_id AND sa.teacher_id = :teacher_id";
        if ($hasTerm) {
            $where .= " AND sa.term = :term";
        }
        if ($hasYear) {
            $where .= " AND sa.academic_year = :year";
        }

        $sql = "SELECT sa.id, sa.teacher_id, sa.class_id, sa.subject_id, c.name as class_name, s.name as subject_name
                FROM subject_assignments sa
                JOIN classes c ON sa.class_id = c.id
                JOIN subjects s ON sa.subject_id = s.id
                $where";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue(':sa_id', $subjectAssignmentId, PDO::PARAM_INT);
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        if ($hasTerm) {
            $stmt->bindValue(':term', $term);
        }
        if ($hasYear) {
            $stmt->bindValue(':year', $year);
        }
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            Response::forbidden('Access denied to this subject assignment for the current term/session');
        }
        return $row;
    }

    private function fetchExamForTeacher(int $teacherId, int $examId): array {
        $stmt = $this->conn->prepare("SELECT * FROM cbt_exams WHERE id = :id AND teacher_id = :teacher_id AND status = 'Active'");
        $stmt->bindValue(':id', $examId, PDO::PARAM_INT);
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $stmt->execute();
        $exam = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$exam) {
            Response::notFound('CBT exam not found');
        }
        return $exam;
    }

    private function fetchAttemptForStudent(int $studentId, int $attemptId): array {
        $stmt = $this->conn->prepare("SELECT a.*, e.duration_minutes, e.published, e.starts_at, e.ends_at, e.term as exam_term, e.academic_year as exam_year, e.class_id, e.allow_review
                                      FROM cbt_attempts a
                                      JOIN cbt_exams e ON a.exam_id = e.id
                                      WHERE a.id = :id AND a.student_id = :student_id");
        $stmt->bindValue(':id', $attemptId, PDO::PARAM_INT);
        $stmt->bindValue(':student_id', $studentId, PDO::PARAM_INT);
        $stmt->execute();
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$attempt) {
            Response::notFound('Attempt not found');
        }
        return $attempt;
    }

    private function computeAttemptExpiresAt(array $attempt): int {
        $startedAt = strtotime((string)$attempt['started_at']);
        $duration = (int)($attempt['duration_minutes'] ?? 0);
        if ($startedAt <= 0 || $duration <= 0) {
            return 0;
        }
        return $startedAt + ($duration * 60);
    }

    private function ensureNotExpiredOrAutoSubmit(array $attempt, int $studentId): ?array {
        if (($attempt['status'] ?? '') !== 'in_progress') {
            return null;
        }
        $expiresAt = $this->computeAttemptExpiresAt($attempt);
        if ($expiresAt > 0 && time() > $expiresAt) {
            return $this->submitAttemptInternal((int)$attempt['id'], $studentId, true);
        }
        return null;
    }

    private function remarkForPercentage(float $pct): string {
        if ($pct >= 90) return 'Excellent';
        if ($pct >= 80) return 'Very Good';
        if ($pct >= 70) return 'Good';
        if ($pct >= 60) return 'Satisfactory';
        if ($pct >= 50) return 'Fair';
        return 'Fail';
    }

    private function calculateGradeFromTotal(float $total): string {
        if ($total >= 70) return 'A';
        if ($total >= 60) return 'B';
        if ($total >= 50) return 'C';
        if ($total >= 45) return 'D';
        if ($total >= 40) return 'E';
        return 'F';
    }

    private function remarkFromGrade(string $grade): string {
        $g = strtoupper(trim($grade));
        if ($g === 'A') return 'Excellent';
        if ($g === 'B') return 'Very Good';
        if ($g === 'C') return 'Good';
        if ($g === 'D') return 'Fair';
        if ($g === 'E') return 'Pass';
        return 'Fail';
    }

    private function submitAttemptInternal(int $attemptId, int $studentId, bool $auto = false): array {
        $attempt = $this->fetchAttemptForStudent($studentId, $attemptId);

        if (($attempt['status'] ?? '') !== 'in_progress') {
            // Already submitted/scored
            return [
                'attempt_id' => (int)$attemptId,
                'status' => (string)$attempt['status'],
                'score' => (int)($attempt['score'] ?? 0),
                'max_score' => (int)($attempt['max_score'] ?? 0),
                'percentage' => (float)($attempt['percentage'] ?? 0),
                'remark' => $attempt['remark'] ?? null,
                'auto_submitted' => false,
            ];
        }

        $examId = (int)$attempt['exam_id'];

        // Score using persisted selected questions in cbt_answers
        $qStmt = $this->conn->prepare("SELECT ans.id as answer_row_id, ans.question_id, ans.answer_json, q.correct_answer_json, q.marks
                                       FROM cbt_answers ans
                                       JOIN cbt_questions q ON ans.question_id = q.id
                                       WHERE ans.attempt_id = :attempt_id AND q.exam_id = :exam_id");
        $qStmt->bindValue(':attempt_id', $attemptId, PDO::PARAM_INT);
        $qStmt->bindValue(':exam_id', $examId, PDO::PARAM_INT);
        $qStmt->execute();
        $rows = $qStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $score = 0;
        $max = 0;

        foreach ($rows as $r) {
            $marks = (int)($r['marks'] ?? 1);
            $max += $marks;

            $given = $r['answer_json'];
            $correct = $r['correct_answer_json'];

            $isCorrect = false;
            // Compare decoded JSON when possible; fallback to trimmed string
            $givenDecoded = json_decode((string)$given, true);
            $correctDecoded = json_decode((string)$correct, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $isCorrect = $givenDecoded !== null && $givenDecoded === $correctDecoded;
            } else {
                $isCorrect = trim((string)$given) !== '' && trim((string)$given) === trim((string)$correct);
            }

            $awarded = $isCorrect ? $marks : 0;
            $score += $awarded;

            $u = $this->conn->prepare("UPDATE cbt_answers SET is_correct = :is_correct, marks_awarded = :awarded, updated_at = NOW() WHERE id = :id");
            $u->bindValue(':is_correct', $isCorrect ? 1 : 0, PDO::PARAM_INT);
            $u->bindValue(':awarded', $awarded, PDO::PARAM_INT);
            $u->bindValue(':id', (int)$r['answer_row_id'], PDO::PARAM_INT);
            $u->execute();
        }

        $pct = $max > 0 ? round(($score / $max) * 100, 2) : 0.0;
        $remark = $this->remarkForPercentage((float)$pct);

        $status = 'scored';
        $stmt = $this->conn->prepare("UPDATE cbt_attempts SET status = :status, submitted_at = IFNULL(submitted_at, NOW()), score = :score, max_score = :max_score, percentage = :pct, remark = :remark, updated_at = NOW() WHERE id = :id AND student_id = :student_id");
        $stmt->bindValue(':status', $status);
        $stmt->bindValue(':score', $score, PDO::PARAM_INT);
        $stmt->bindValue(':max_score', $max, PDO::PARAM_INT);
        $stmt->bindValue(':pct', (string)$pct);
        $stmt->bindValue(':remark', $remark);
        $stmt->bindValue(':id', $attemptId, PDO::PARAM_INT);
        $stmt->bindValue(':student_id', $studentId, PDO::PARAM_INT);
        $stmt->execute();

        RealtimeEvents::publish(['cbt_attempts'], [
            'action' => $auto ? 'auto_submitted' : 'submitted',
            'attempt_id' => (int)$attemptId,
            'exam_id' => (int)$examId,
            'student_id' => (int)$studentId,
        ]);

        return [
            'attempt_id' => (int)$attemptId,
            'status' => $status,
            'score' => $score,
            'max_score' => $max,
            'percentage' => (float)$pct,
            'remark' => $remark,
            'auto_submitted' => $auto,
        ];
    }

    // =========================
    // Teacher endpoints
    // =========================

    public function getTeacherSubjectAssignments() {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        if (!$teacherId) {
            Response::forbidden('Teacher profile not linked');
        }

        $settings = $this->getCurrentSettings();
        $term = $settings['term'];
        $year = $settings['academic_year'];

        $hasTerm = $this->columnExists('subject_assignments', 'term');
        $hasYear = $this->columnExists('subject_assignments', 'academic_year');

        $where = "WHERE sa.teacher_id = :teacher_id";
        if ($hasTerm) {
            $where .= " AND sa.term = :term";
        }
        if ($hasYear) {
            $where .= " AND sa.academic_year = :year";
        }

        $sql = "SELECT sa.*, c.name as class_name, s.name as subject_name
                FROM subject_assignments sa
                JOIN classes c ON sa.class_id = c.id
                JOIN subjects s ON sa.subject_id = s.id
                $where
                ORDER BY c.name ASC, s.name ASC";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        if ($hasTerm) {
            $stmt->bindValue(':term', $term);
        }
        if ($hasYear) {
            $stmt->bindValue(':year', $year);
        }
        $stmt->execute();

        Response::success([
            'term' => $term,
            'academic_year' => $year,
            'items' => $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [],
        ]);
    }

    public function getTeacherExams() {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        if (!$teacherId) {
            Response::forbidden('Teacher profile not linked');
        }

        $settings = $this->getCurrentSettings();
        $term = $settings['term'];
        $year = $settings['academic_year'];

        $stmt = $this->conn->prepare("SELECT e.*,
                    c.name as class_name,
                    s.name as subject_name
            FROM cbt_exams e
            JOIN classes c ON e.class_id = c.id
            JOIN subjects s ON e.subject_id = s.id
            WHERE e.teacher_id = :teacher_id AND e.term = :term AND e.academic_year = :year AND e.status = 'Active'
            ORDER BY e.created_at DESC");
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $stmt->bindValue(':term', $term);
        $stmt->bindValue(':year', $year);
        $stmt->execute();

        Response::success([
            'term' => $term,
            'academic_year' => $year,
            'items' => $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [],
        ]);
    }

    public function createTeacherExam() {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        if (!$teacherId) {
            Response::forbidden('Teacher profile not linked');
        }

        $data = json_decode(file_get_contents('php://input'), true);
        Middleware::validateRequired($data, ['subject_assignment_id', 'title', 'duration_minutes', 'score_slot']);

        $settings = $this->getCurrentSettings();
        $term = $settings['term'];
        $year = $settings['academic_year'];

        $saId = Middleware::validateInteger($data['subject_assignment_id'], 'subject_assignment_id');
        $title = Middleware::sanitizeString($data['title']);
        $instructions = isset($data['instructions']) ? (string)$data['instructions'] : null;
        $duration = Middleware::validatePositive($data['duration_minutes'], 'duration_minutes');
        $scoreSlot = Middleware::validateEnum($data['score_slot'], ['first_test', 'second_test'], 'score_slot');

        $startsAt = isset($data['starts_at']) && $data['starts_at'] ? (string)$data['starts_at'] : null;
        $endsAt = isset($data['ends_at']) && $data['ends_at'] ? (string)$data['ends_at'] : null;
        $allowReview = isset($data['allow_review']) ? ((int)$data['allow_review'] ? 1 : 0) : 0;

        // Validate subject assignment ownership for current term/year
        $sa = $this->fetchTeacherSubjectAssignmentForCurrent($teacherId, $saId, $term, $year);

        $stmt = $this->conn->prepare("INSERT INTO cbt_exams (title, instructions, class_id, subject_id, teacher_id, academic_year, term, duration_minutes, total_marks, score_slot, published, published_at, starts_at, ends_at, allow_review, status, created_at, updated_at)
                                      VALUES (:title, :instructions, :class_id, :subject_id, :teacher_id, :year, :term, :duration, 0, :score_slot, 0, NULL, :starts_at, :ends_at, :allow_review, 'Active', NOW(), NOW())");
        $stmt->bindValue(':title', $title);
        $stmt->bindValue(':instructions', $instructions);
        $stmt->bindValue(':class_id', (int)$sa['class_id'], PDO::PARAM_INT);
        $stmt->bindValue(':subject_id', (int)$sa['subject_id'], PDO::PARAM_INT);
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $stmt->bindValue(':year', $year);
        $stmt->bindValue(':term', $term);
        $stmt->bindValue(':duration', (int)$duration, PDO::PARAM_INT);
        $stmt->bindValue(':score_slot', $scoreSlot);
        $stmt->bindValue(':starts_at', $startsAt);
        $stmt->bindValue(':ends_at', $endsAt);
        $stmt->bindValue(':allow_review', $allowReview, PDO::PARAM_INT);
        $stmt->execute();

        $examId = (int)$this->conn->lastInsertId();

        RealtimeEvents::publish(['cbt_exams'], [
            'action' => 'created',
            'exam_id' => $examId,
            'teacher_id' => $teacherId,
        ]);

        Response::created(['id' => $examId], 'CBT exam created');
    }

    public function updateTeacherExam($id) {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        if (!$teacherId) {
            Response::forbidden('Teacher profile not linked');
        }

        $examId = Middleware::validateInteger($id, 'exam_id');
        $exam = $this->fetchExamForTeacher($teacherId, $examId);

        if ((int)($exam['published'] ?? 0) === 1) {
            Response::forbidden('Cannot edit a published exam');
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || !is_array($data)) {
            Response::badRequest('Invalid payload');
        }

        $fields = [];
        $params = [':id' => $examId, ':teacher_id' => $teacherId];

        if (isset($data['title'])) {
            $fields[] = 'title = :title';
            $params[':title'] = Middleware::sanitizeString($data['title']);
        }
        if (array_key_exists('instructions', $data)) {
            $fields[] = 'instructions = :instructions';
            $params[':instructions'] = $data['instructions'] !== null ? (string)$data['instructions'] : null;
        }
        if (isset($data['duration_minutes'])) {
            $fields[] = 'duration_minutes = :duration';
            $params[':duration'] = (int)Middleware::validatePositive($data['duration_minutes'], 'duration_minutes');
        }
        if (isset($data['score_slot'])) {
            $fields[] = 'score_slot = :score_slot';
            $params[':score_slot'] = Middleware::validateEnum($data['score_slot'], ['first_test', 'second_test'], 'score_slot');
        }
        if (array_key_exists('starts_at', $data)) {
            $fields[] = 'starts_at = :starts_at';
            $params[':starts_at'] = $data['starts_at'] ? (string)$data['starts_at'] : null;
        }
        if (array_key_exists('ends_at', $data)) {
            $fields[] = 'ends_at = :ends_at';
            $params[':ends_at'] = $data['ends_at'] ? (string)$data['ends_at'] : null;
        }
        if (isset($data['allow_review'])) {
            $fields[] = 'allow_review = :allow_review';
            $params[':allow_review'] = ((int)$data['allow_review']) ? 1 : 0;
        }

        if (count($fields) === 0) {
            Response::success(null, 'No changes');
        }

        $sql = "UPDATE cbt_exams SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = :id AND teacher_id = :teacher_id";
        $stmt = $this->conn->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->execute();

        RealtimeEvents::publish(['cbt_exams'], [
            'action' => 'updated',
            'exam_id' => $examId,
            'teacher_id' => $teacherId,
        ]);

        Response::success(null, 'CBT exam updated');
    }

    public function publishTeacherExam($id) {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        $examId = Middleware::validateInteger($id, 'exam_id');

        $exam = $this->fetchExamForTeacher($teacherId, $examId);

        // Require at least 1 question
        $q = $this->conn->prepare("SELECT COUNT(*) FROM cbt_questions WHERE exam_id = :exam_id");
        $q->bindValue(':exam_id', $examId, PDO::PARAM_INT);
        $q->execute();
        if ((int)$q->fetchColumn() <= 0) {
            Response::badRequest('Add at least one question before publishing');
        }

        $stmt = $this->conn->prepare("UPDATE cbt_exams SET published = 1, published_at = NOW(), updated_at = NOW() WHERE id = :id AND teacher_id = :teacher_id");
        $stmt->bindValue(':id', $examId, PDO::PARAM_INT);
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $stmt->execute();

        RealtimeEvents::publish(['cbt_exams'], [
            'action' => 'published',
            'exam_id' => $examId,
            'teacher_id' => $teacherId,
        ]);

        Response::success(null, 'CBT exam published');
    }

    public function unpublishTeacherExam($id) {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        $examId = Middleware::validateInteger($id, 'exam_id');

        $this->fetchExamForTeacher($teacherId, $examId);

        $stmt = $this->conn->prepare("UPDATE cbt_exams SET published = 0, published_at = NULL, updated_at = NOW() WHERE id = :id AND teacher_id = :teacher_id");
        $stmt->bindValue(':id', $examId, PDO::PARAM_INT);
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $stmt->execute();

        RealtimeEvents::publish(['cbt_exams'], [
            'action' => 'unpublished',
            'exam_id' => $examId,
            'teacher_id' => $teacherId,
        ]);

        Response::success(null, 'CBT exam unpublished');
    }

    public function getTeacherExamQuestions($id) {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        $examId = Middleware::validateInteger($id, 'exam_id');

        $this->fetchExamForTeacher($teacherId, $examId);

        $stmt = $this->conn->prepare("SELECT * FROM cbt_questions WHERE exam_id = :exam_id ORDER BY sort_order ASC, id ASC");
        $stmt->bindValue(':exam_id', $examId, PDO::PARAM_INT);
        $stmt->execute();

        Response::success($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
    }

    public function createTeacherQuestion($id) {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        $examId = Middleware::validateInteger($id, 'exam_id');

        $exam = $this->fetchExamForTeacher($teacherId, $examId);
        if ((int)($exam['published'] ?? 0) === 1) {
            Response::forbidden('Cannot edit questions while exam is published');
        }

        $data = json_decode(file_get_contents('php://input'), true);
        Middleware::validateRequired($data, ['question_type', 'question_text', 'correct_answer_json']);

        $type = Middleware::validateEnum($data['question_type'], ['single_choice', 'true_false'], 'question_type');
        $text = (string)$data['question_text'];
        $optionsJson = array_key_exists('options_json', $data) ? ($data['options_json'] !== null ? (string)$data['options_json'] : null) : null;
        $correctJson = (string)$data['correct_answer_json'];
        $marks = isset($data['marks']) ? (int)Middleware::validatePositive($data['marks'], 'marks') : 1;

        $sortOrder = 0;
        $s = $this->conn->prepare("SELECT COALESCE(MAX(sort_order), 0) FROM cbt_questions WHERE exam_id = :exam_id");
        $s->bindValue(':exam_id', $examId, PDO::PARAM_INT);
        $s->execute();
        $sortOrder = ((int)$s->fetchColumn()) + 1;

        $stmt = $this->conn->prepare("INSERT INTO cbt_questions (exam_id, question_type, question_text, options_json, correct_answer_json, marks, sort_order, created_at, updated_at)
                                      VALUES (:exam_id, :type, :text, :options, :correct, :marks, :sort_order, NOW(), NOW())");
        $stmt->bindValue(':exam_id', $examId, PDO::PARAM_INT);
        $stmt->bindValue(':type', $type);
        $stmt->bindValue(':text', $text);
        $stmt->bindValue(':options', $optionsJson);
        $stmt->bindValue(':correct', $correctJson);
        $stmt->bindValue(':marks', $marks, PDO::PARAM_INT);
        $stmt->bindValue(':sort_order', $sortOrder, PDO::PARAM_INT);
        $stmt->execute();

        $questionId = (int)$this->conn->lastInsertId();

        RealtimeEvents::publish(['cbt_exams'], [
            'action' => 'question_created',
            'exam_id' => $examId,
            'question_id' => $questionId,
            'teacher_id' => $teacherId,
        ]);

        Response::created(['id' => $questionId], 'Question added');
    }

    public function applyTeacherExamScores($id) {
        $token = Middleware::requireRole('teacher');
        $teacherId = (int)($token['linked_id'] ?? 0);
        if (!$teacherId) {
            Response::forbidden('Teacher profile not linked');
        }

        $examId = Middleware::validateInteger($id, 'exam_id');

        $settings = $this->getCurrentSettings();
        $term = $settings['term'];
        $year = $settings['academic_year'];

        $exam = $this->fetchExamForTeacher($teacherId, $examId);
        if ((string)($exam['term'] ?? '') !== (string)$term || (string)($exam['academic_year'] ?? '') !== (string)$year) {
            Response::forbidden('Exam is not in the current term/session');
        }

        $scoreSlot = (string)($exam['score_slot'] ?? '');
        if (!in_array($scoreSlot, ['first_test', 'second_test'], true)) {
            Response::serverError('Invalid exam score slot');
        }

        // Find the matching subject_assignment_id for this teacher/class/subject/term/year
        $saStmt = $this->conn->prepare("SELECT id FROM subject_assignments WHERE teacher_id = :teacher_id AND class_id = :class_id AND subject_id = :subject_id AND term = :term AND academic_year = :year LIMIT 1");
        $saStmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $saStmt->bindValue(':class_id', (int)$exam['class_id'], PDO::PARAM_INT);
        $saStmt->bindValue(':subject_id', (int)$exam['subject_id'], PDO::PARAM_INT);
        $saStmt->bindValue(':term', $term);
        $saStmt->bindValue(':year', $year);
        $saStmt->execute();
        $subjectAssignmentId = (int)($saStmt->fetchColumn() ?: 0);
        if (!$subjectAssignmentId) {
            Response::serverError('No matching subject assignment found for this exam');
        }

        // Pull scored attempts
        $aStmt = $this->conn->prepare("SELECT student_id, percentage FROM cbt_attempts WHERE exam_id = :exam_id AND academic_year = :year AND term = :term AND status = 'scored'");
        $aStmt->bindValue(':exam_id', $examId, PDO::PARAM_INT);
        $aStmt->bindValue(':year', $year);
        $aStmt->bindValue(':term', $term);
        $aStmt->execute();
        $attempts = $aStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        if (count($attempts) === 0) {
            Response::success([
                'applied' => 0,
                'skipped' => 0,
                'message' => 'No scored attempts found',
            ]);
        }

        $applied = 0;
        $skipped = 0;

        $this->conn->beginTransaction();
        try {
            foreach ($attempts as $a) {
                $studentId = (int)$a['student_id'];
                $pct = (float)($a['percentage'] ?? 0);

                // Map percentage (0-100) to CA (0-40)
                $ca = round(max(0.0, min(100.0, $pct)) * 0.4, 2);

                // Does a score row exist?
                $existingStmt = $this->conn->prepare("SELECT id, ca1, ca2, exam, status FROM scores WHERE student_id = :student_id AND subject_assignment_id = :sa_id LIMIT 1");
                $existingStmt->bindValue(':student_id', $studentId, PDO::PARAM_INT);
                $existingStmt->bindValue(':sa_id', $subjectAssignmentId, PDO::PARAM_INT);
                $existingStmt->execute();
                $existing = $existingStmt->fetch(PDO::FETCH_ASSOC);

                $targetCol = $scoreSlot === 'first_test' ? 'ca1' : 'ca2';

                if ($existing) {
                    $existingId = (int)$existing['id'];
                    $currentVal = $existing[$targetCol];

                    // Fill-only: only write if NULL
                    if ($currentVal !== null) {
                        $skipped++;
                        continue;
                    }

                    $newCa1 = $existing['ca1'];
                    $newCa2 = $existing['ca2'];
                    if ($targetCol === 'ca1') $newCa1 = $ca;
                    if ($targetCol === 'ca2') $newCa2 = $ca;

                    $examVal = $existing['exam'];
                    $total = (float)($newCa1 ?? 0) + (float)($newCa2 ?? 0) + (float)($examVal ?? 0);
                    $grade = $this->calculateGradeFromTotal($total);
                    $remark = $this->remarkFromGrade($grade);

                    $u = $this->conn->prepare("UPDATE scores SET ca1 = :ca1, ca2 = :ca2, total = :total, grade = :grade, remark = :remark, term = :term, academic_year = :year WHERE id = :id");
                    $u->bindValue(':ca1', $newCa1);
                    $u->bindValue(':ca2', $newCa2);
                    $u->bindValue(':total', $total);
                    $u->bindValue(':grade', $grade);
                    $u->bindValue(':remark', $remark);
                    $u->bindValue(':term', $term);
                    $u->bindValue(':year', $year);
                    $u->bindValue(':id', $existingId, PDO::PARAM_INT);
                    $u->execute();
                    $applied++;
                } else {
                    // Insert as Draft row with only the target CA filled
                    $ca1 = $scoreSlot === 'first_test' ? $ca : null;
                    $ca2 = $scoreSlot === 'second_test' ? $ca : null;
                    $examVal = null;

                    $total = (float)($ca1 ?? 0) + (float)($ca2 ?? 0) + (float)($examVal ?? 0);
                    $grade = $this->calculateGradeFromTotal($total);
                    $remark = $this->remarkFromGrade($grade);

                    $ins = $this->conn->prepare("INSERT INTO scores (student_id, subject_assignment_id, ca1, ca2, exam, total, grade, remark, class_average, class_min, class_max, entered_by, status, term, academic_year)
                                                 VALUES (:student_id, :sa_id, :ca1, :ca2, :exam, :total, :grade, :remark, NULL, NULL, NULL, :entered_by, 'Draft', :term, :year)");
                    $ins->bindValue(':student_id', $studentId, PDO::PARAM_INT);
                    $ins->bindValue(':sa_id', $subjectAssignmentId, PDO::PARAM_INT);
                    $ins->bindValue(':ca1', $ca1);
                    $ins->bindValue(':ca2', $ca2);
                    $ins->bindValue(':exam', $examVal);
                    $ins->bindValue(':total', $total);
                    $ins->bindValue(':grade', $grade);
                    $ins->bindValue(':remark', $remark);
                    $ins->bindValue(':entered_by', (int)($token['user_id'] ?? 0), PDO::PARAM_INT);
                    $ins->bindValue(':term', $term);
                    $ins->bindValue(':year', $year);
                    $ins->execute();
                    $applied++;
                }
            }

            $this->conn->commit();
        } catch (Throwable $e) {
            $this->conn->rollBack();
            Response::serverError('Failed to apply CBT scores');
        }

        RealtimeEvents::publish(['scores'], [
            'action' => 'cbt_applied',
            'exam_id' => $examId,
            'subject_assignment_id' => $subjectAssignmentId,
            'teacher_id' => $teacherId,
        ]);

        Response::success([
            'applied' => $applied,
            'skipped' => $skipped,
            'score_slot' => $scoreSlot,
        ], 'CBT scores applied');
    }

    // =========================
    // Student endpoints
    // =========================

    public function listStudentExams() {
        $token = Middleware::requireRole('student');
        $studentId = (int)($token['linked_id'] ?? 0);
        if (!$studentId) {
            Response::forbidden('Student profile not linked');
        }

        $settings = $this->getCurrentSettings();
        $term = $settings['term'];
        $year = $settings['academic_year'];

        // Determine student class
        $st = $this->conn->prepare("SELECT class_id FROM students WHERE id = :id AND status = 'Active'");
        $st->bindValue(':id', $studentId, PDO::PARAM_INT);
        $st->execute();
        $student = $st->fetch(PDO::FETCH_ASSOC);
        if (!$student) {
            Response::forbidden('Student not found or inactive');
        }

        $classId = (int)$student['class_id'];

        $stmt = $this->conn->prepare("SELECT e.id, e.title, e.instructions, e.class_id, e.subject_id, e.teacher_id, e.academic_year, e.term, e.duration_minutes, e.score_slot, e.published, e.starts_at, e.ends_at, e.allow_review,
                    s.name as subject_name
            FROM cbt_exams e
            JOIN subjects s ON e.subject_id = s.id
            WHERE e.published = 1 AND e.status = 'Active' AND e.class_id = :class_id AND e.term = :term AND e.academic_year = :year
            ORDER BY e.created_at DESC");
        $stmt->bindValue(':class_id', $classId, PDO::PARAM_INT);
        $stmt->bindValue(':term', $term);
        $stmt->bindValue(':year', $year);
        $stmt->execute();

        Response::success([
            'term' => $term,
            'academic_year' => $year,
            'items' => $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [],
        ]);
    }

    public function startStudentAttempt($examId) {
        $token = Middleware::requireRole('student');
        $studentId = (int)($token['linked_id'] ?? 0);
        $examId = Middleware::validateInteger($examId, 'exam_id');

        $settings = $this->getCurrentSettings();
        $term = $settings['term'];
        $year = $settings['academic_year'];

        // Determine student class
        $st = $this->conn->prepare("SELECT class_id FROM students WHERE id = :id AND status = 'Active'");
        $st->bindValue(':id', $studentId, PDO::PARAM_INT);
        $st->execute();
        $student = $st->fetch(PDO::FETCH_ASSOC);
        if (!$student) {
            Response::forbidden('Student not found or inactive');
        }
        $classId = (int)$student['class_id'];

        // Load exam
        $e = $this->conn->prepare("SELECT * FROM cbt_exams WHERE id = :id AND published = 1 AND status = 'Active' AND class_id = :class_id AND term = :term AND academic_year = :year");
        $e->bindValue(':id', $examId, PDO::PARAM_INT);
        $e->bindValue(':class_id', $classId, PDO::PARAM_INT);
        $e->bindValue(':term', $term);
        $e->bindValue(':year', $year);
        $e->execute();
        $exam = $e->fetch(PDO::FETCH_ASSOC);
        if (!$exam) {
            Response::notFound('Exam not available');
        }

        // Optional window enforcement
        $nowTs = time();
        if (!empty($exam['starts_at'])) {
            $starts = strtotime((string)$exam['starts_at']);
            if ($starts > 0 && $nowTs < $starts) {
                Response::forbidden('Exam has not started');
            }
        }
        if (!empty($exam['ends_at'])) {
            $ends = strtotime((string)$exam['ends_at']);
            if ($ends > 0 && $nowTs > $ends) {
                Response::forbidden('Exam has ended');
            }
        }

        // Create or reuse attempt (unique per exam/student/term/year)
        $this->conn->beginTransaction();
        try {
            $ins = $this->conn->prepare("INSERT INTO cbt_attempts (exam_id, student_id, academic_year, term, status, started_at, score, max_score, percentage, created_at, updated_at)
                                         VALUES (:exam_id, :student_id, :year, :term, 'in_progress', NOW(), 0, 0, 0.00, NOW(), NOW())");
            $ins->bindValue(':exam_id', $examId, PDO::PARAM_INT);
            $ins->bindValue(':student_id', $studentId, PDO::PARAM_INT);
            $ins->bindValue(':year', $year);
            $ins->bindValue(':term', $term);
            $ins->execute();
            $attemptId = (int)$this->conn->lastInsertId();

            // Select/shuffle questions (default limit 30)
            $qStmt = $this->conn->prepare("SELECT id, question_type, question_text, options_json, marks FROM cbt_questions WHERE exam_id = :exam_id ORDER BY id ASC");
            $qStmt->bindValue(':exam_id', $examId, PDO::PARAM_INT);
            $qStmt->execute();
            $questions = $qStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            if (count($questions) === 0) {
                $this->conn->rollBack();
                Response::badRequest('Exam has no questions');
            }

            // Shuffle and select subset
            shuffle($questions);
            $limit = 30;
            if (count($questions) > $limit) {
                $questions = array_slice($questions, 0, $limit);
            }

            // Persist selected question set via placeholder answers
            $aIns = $this->conn->prepare("INSERT INTO cbt_answers (attempt_id, question_id, answer_json, is_correct, marks_awarded, created_at, updated_at)
                                          VALUES (:attempt_id, :question_id, NULL, NULL, 0, NOW(), NOW())");
            foreach ($questions as $q) {
                $aIns->bindValue(':attempt_id', $attemptId, PDO::PARAM_INT);
                $aIns->bindValue(':question_id', (int)$q['id'], PDO::PARAM_INT);
                $aIns->execute();
            }

            $this->conn->commit();

            RealtimeEvents::publish(['cbt_attempts'], [
                'action' => 'started',
                'attempt_id' => $attemptId,
                'exam_id' => $examId,
                'student_id' => $studentId,
            ]);

            // Return attempt + questions (without correct answers)
            $expiresAt = $this->computeAttemptExpiresAt([
                'started_at' => date('Y-m-d H:i:s'),
                'duration_minutes' => (int)$exam['duration_minutes'],
            ]);

            Response::created([
                'attempt_id' => $attemptId,
                'exam' => [
                    'id' => (int)$exam['id'],
                    'title' => $exam['title'],
                    'instructions' => $exam['instructions'],
                    'duration_minutes' => (int)$exam['duration_minutes'],
                    'allow_review' => (int)($exam['allow_review'] ?? 0),
                ],
                'questions' => array_map(function ($q) {
                    return [
                        'id' => (int)$q['id'],
                        'question_type' => $q['question_type'],
                        'question_text' => $q['question_text'],
                        'options_json' => $q['options_json'],
                        'marks' => (int)($q['marks'] ?? 1),
                    ];
                }, $questions),
                'expires_at_unix' => $expiresAt,
            ], 'Attempt started');

        } catch (Throwable $e) {
            $this->conn->rollBack();

            // Duplicate attempt
            if (strpos((string)$e->getMessage(), 'uniq_cbt_attempt_exam_student_term') !== false) {
                // Return the existing attempt
                $stmt = $this->conn->prepare("SELECT id FROM cbt_attempts WHERE exam_id = :exam_id AND student_id = :student_id AND academic_year = :year AND term = :term");
                $stmt->bindValue(':exam_id', $examId, PDO::PARAM_INT);
                $stmt->bindValue(':student_id', $studentId, PDO::PARAM_INT);
                $stmt->bindValue(':year', $year);
                $stmt->bindValue(':term', $term);
                $stmt->execute();
                $existingId = (int)($stmt->fetchColumn() ?: 0);
                if ($existingId) {
                    Response::success(['attempt_id' => $existingId], 'Attempt already exists');
                }
            }

            Response::serverError('Failed to start attempt');
        }
    }

    public function getStudentAttempt($attemptId) {
        $token = Middleware::requireRole('student');
        $studentId = (int)($token['linked_id'] ?? 0);
        $attemptId = Middleware::validateInteger($attemptId, 'attempt_id');

        $attempt = $this->fetchAttemptForStudent($studentId, $attemptId);

        $auto = $this->ensureNotExpiredOrAutoSubmit($attempt, $studentId);
        if ($auto) {
            Response::success($auto, 'Attempt expired and was auto-submitted');
        }

        $expiresAt = $this->computeAttemptExpiresAt($attempt);

        Response::success([
            'attempt_id' => (int)$attemptId,
            'status' => (string)$attempt['status'],
            'started_at' => $attempt['started_at'],
            'submitted_at' => $attempt['submitted_at'],
            'expires_at_unix' => $expiresAt,
            'score' => (int)($attempt['score'] ?? 0),
            'max_score' => (int)($attempt['max_score'] ?? 0),
            'percentage' => (float)($attempt['percentage'] ?? 0),
            'remark' => $attempt['remark'] ?? null,
        ]);
    }

    public function saveStudentAnswer($attemptId) {
        $token = Middleware::requireRole('student');
        $studentId = (int)($token['linked_id'] ?? 0);
        $attemptId = Middleware::validateInteger($attemptId, 'attempt_id');

        $data = json_decode(file_get_contents('php://input'), true);
        Middleware::validateRequired($data, ['question_id']);

        $questionId = Middleware::validateInteger($data['question_id'], 'question_id');
        $answerJson = array_key_exists('answer_json', $data) ? ($data['answer_json'] !== null ? (string)$data['answer_json'] : null) : null;

        $attempt = $this->fetchAttemptForStudent($studentId, $attemptId);

        $auto = $this->ensureNotExpiredOrAutoSubmit($attempt, $studentId);
        if ($auto) {
            Response::success($auto, 'Attempt expired and was auto-submitted');
        }

        if (($attempt['status'] ?? '') !== 'in_progress') {
            Response::forbidden('Attempt is not in progress');
        }

        // Only allow answers for selected questions (row must exist)
        $stmt = $this->conn->prepare("UPDATE cbt_answers SET answer_json = :answer_json, updated_at = NOW() WHERE attempt_id = :attempt_id AND question_id = :question_id");
        $stmt->bindValue(':answer_json', $answerJson);
        $stmt->bindValue(':attempt_id', $attemptId, PDO::PARAM_INT);
        $stmt->bindValue(':question_id', $questionId, PDO::PARAM_INT);
        $stmt->execute();

        Response::success(null, 'Saved');
    }

    public function submitStudentAttempt($attemptId) {
        $token = Middleware::requireRole('student');
        $studentId = (int)($token['linked_id'] ?? 0);
        $attemptId = Middleware::validateInteger($attemptId, 'attempt_id');

        $attempt = $this->fetchAttemptForStudent($studentId, $attemptId);

        $auto = $this->ensureNotExpiredOrAutoSubmit($attempt, $studentId);
        if ($auto) {
            Response::success($auto, 'Attempt expired and was auto-submitted');
        }

        $result = $this->submitAttemptInternal($attemptId, $studentId, false);
        Response::success($result, 'Submitted');
    }
}
