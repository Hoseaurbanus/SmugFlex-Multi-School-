var qe=Object.defineProperty,Je=Object.defineProperties;var Qe=Object.getOwnPropertyDescriptors;var Pe=Object.getOwnPropertySymbols;var Ze=Object.prototype.hasOwnProperty,De=Object.prototype.propertyIsEnumerable;var Te=(f,p,t)=>p in f?qe(f,p,{enumerable:!0,configurable:!0,writable:!0,value:t}):f[p]=t,Q=(f,p)=>{for(var t in p||(p={}))Ze.call(p,t)&&Te(f,t,p[t]);if(Pe)for(var t of Pe(p))De.call(p,t)&&Te(f,t,p[t]);return f},me=(f,p)=>Je(f,Qe(p));var te=(f,p,t)=>new Promise((N,W)=>{var u=v=>{try{X(t.next(v))}catch(h){W(h)}},_=v=>{try{X(t.throw(v))}catch(h){W(h)}},X=v=>v.done?N(v.value):Promise.resolve(v.value).then(u,_);X((t=t.apply(f,p)).next())});import{r as L,j as e}from"./radix-iRPhyIl_.js";import{u as Ee,k as et,B as xe,A as he}from"./index-CrAt7Sui.js";import{H as tt}from"./utils-On6yIdlW.js";const it=f=>{const p=typeof f=="number"?f:Number(f);if(!Number.isFinite(p)||p<=0)return"___";const t=Math.floor(p),N=t%100;if(N>=11&&N<=13)return`${t}th`;const W=t%10;return W===1?`${t}st`:W===2?`${t}nd`:W===3?`${t}rd`:`${t}th`},ot=`
@media print {
  body * {
    visibility: hidden;
  }
  .print-content, .print-content * {
    visibility: visible;
  }
  .print-content {
    position: absolute;
    left: 0;
    top: 0;
    width: 210mm;
    height: 297mm;
    margin: 0;
    padding: 0;
    border: none;
    overflow: hidden;
  }
  @page {
    size: A4;
    margin: 0;
    padding: 0;
  }
  .no-print {
    display: none !important;
  }
}

@media screen and (max-width: 640px) {
  .print-container {
    width: 100% !important;
    height: auto !important;
    margin: 0 !important;
    padding: 12px !important;
    border: none !important;
    box-shadow: none !important;
    overflow: visible !important;
  }

  .print-content {
    position: static !important;
    left: auto !important;
    top: auto !important;
    width: 100% !important;
    height: auto !important;
    padding: 0 !important;
  }

  .print-table {
    width: 100% !important;
    font-size: 10px !important;
  }

  .print-table th,
  .print-table td {
    padding: 4px !important;
    font-size: 10px !important;
  }
}
`,nt=(f,p)=>te(null,null,function*(){const t=localStorage.getItem("jwt_token"),N=`${he.BASE_URL}/results/scores/by-term?term=${encodeURIComponent(String(f))}&academic_year=${encodeURIComponent(String(p))}`,u=yield(yield fetch(N,{method:"GET",headers:Q({Accept:"application/json"},t?{Authorization:`Bearer ${t}`}:{})})).json(),_=u==null?void 0:u.data;return Array.isArray(_)?_:[]});function rt({student:f,studentClass:p,result:t,detailedScores:N,showActions:W=!1,onDownload:u,onPrint:_,onApprovePrint:X,currentUser:v}){var ze,Ae,Ce;const{schoolSettings:h,loadSchoolSettings:Z,students:ie,classes:oe,teachers:U,scores:Y,subjectAssignments:q,subjects:d,affectiveDomains:E,psychomotorDomains:H,loadScoresFromAPI:pe,loadSubjectAssignmentsFromAPI:ge,loadSubjectsFromAPI:ne,loadAffectiveDomainsFromAPI:re,loadPsychomotorDomainsFromAPI:ae,getClassTeacher:de}=Ee(),[be,fe]=L.useState(!1),[J,K]=L.useState([]),[se,D]=L.useState("");L.useEffect(()=>{let i=!0;return te(null,null,function*(){var o,c;try{const y=String((t==null?void 0:t.academic_year)||""),m=String((t==null?void 0:t.term)||"");if(!y||!m)return;const k=localStorage.getItem("jwt_token"),z=new URLSearchParams({academic_year:y,term:m}),R=yield(yield fetch(`${he.BASE_URL}/signature_settings.php?${z.toString()}`,{method:"GET",headers:Q({Accept:"application/json"},k?{Authorization:`Bearer ${k}`}:{})})).json(),P=String((c=(o=R==null?void 0:R.data)==null?void 0:o.resumption_date)!=null?c:"").trim(),M=/^\d{4}-\d{2}-\d{2}/.test(P)?P.slice(0,10):P;i&&D(M)}catch(y){i&&D("")}}),()=>{i=!1}},[t==null?void 0:t.academic_year,t==null?void 0:t.term]),L.useEffect(()=>{const i=document.createElement("style");return i.textContent=ot,document.head.appendChild(i),()=>{document.head.removeChild(i)}},[]);const V=()=>{window.print()};L.useEffect(()=>{t&&t.student_id&&(Me(),Ie())},[t]);const Ie=()=>te(null,null,function*(){if(!(!t||!t.student_id))try{yield Promise.all([E.length===0&&re(),H.length===0&&ae()])}catch(i){}}),Fe=()=>!t||!t.student_id?{}:t!=null&&t.affective&&typeof t.affective=="object"?t.affective:(Array.isArray(E)?E:[]).find(o=>o.student_id===t.student_id&&o.academic_year===t.academic_year&&o.term===t.term)||{},Be=()=>!t||!t.student_id?{}:t!=null&&t.psychomotor&&typeof t.psychomotor=="object"?t.psychomotor:(Array.isArray(H)?H:[]).find(o=>o.student_id===t.student_id&&o.academic_year===t.academic_year&&o.term===t.term)||{},Me=()=>te(null,null,function*(){var i,r;if(!(!t||!t.student_id))try{const o=(i=t==null?void 0:t.term)!=null?i:null,c=(r=t==null?void 0:t.academic_year)!=null?r:null,y=Array.isArray(Y)?Y:[],m=Array.isArray(q)?q:[],k=!!(o&&c)&&y.some(a=>String(a==null?void 0:a.term)===String(o)&&String(a==null?void 0:a.academic_year)===String(c)),z=!!(o&&c)&&m.some(a=>String(a==null?void 0:a.term)===String(o)&&String(a==null?void 0:a.academic_year)===String(c));yield Promise.all([!k&&pe(o,c),!z&&ge(!1,o,c),d.length===0&&ne()]);const A=Array.isArray(U)?U:[],R=Array.isArray(q)?q:[],P=Array.isArray(d)?d:[],M=Array.isArray(Y)?Y:[];let O=M.filter(a=>a.student_id===t.student_id&&a.academic_year===t.academic_year&&a.term===t.term);if((!N||N.length===0)&&(!t.scores||t.scores.length===0)&&O.length===0){const a=String((t==null?void 0:t.term)||"").trim(),b=String((t==null?void 0:t.academic_year)||"").trim();a&&b&&(O=(yield nt(a,b)).filter(s=>Number(s==null?void 0:s.student_id)===Number(t==null?void 0:t.student_id)).map(s=>{var C,w,S,T,$,x,g;return me(Q({},s),{subject_name:s.subject_name||"Unknown Subject",subject_teacher:s.teacher_name||s.subject_teacher||"Not Assigned",class_average:s.class_average||0,class_minimum:s.class_minimum||0,class_maximum:s.class_maximum||0,first_ca:(w=(C=s.first_ca)!=null?C:s.ca1)!=null?w:0,second_ca:(T=(S=s.second_ca)!=null?S:s.ca2)!=null?T:0,exams:(x=($=s.exams)!=null?$:s.exam)!=null?x:0,total:(g=s.total)!=null?g:0})}).sort((s,C)=>String(s.subject_name).localeCompare(String(C.subject_name))))}if(O=O.map(a=>{const b=R.find(x=>x.id===a.subject_assignment_id),j=b?P.find(x=>x.id===b.subject_id):null,s=b?A.find(x=>x.id===b.teacher_id):null,w=M.filter(x=>{const g=R.find(G=>G.id===x.subject_assignment_id);return g&&g.subject_id===(b==null?void 0:b.subject_id)&&x.academic_year===t.academic_year&&x.term===t.term&&x.total>0}).map(x=>x.total||0),S=w.length>0?w.reduce((x,g)=>x+g,0)/w.length:0,T=w.length>0?Math.min(...w):0,$=w.length>0?Math.max(...w):0;return me(Q({},a),{subject_name:j?j.name:a.subject_name||"Unknown Subject",subject_teacher:s?`${s.firstName} ${s.lastName}`:"Not Assigned",class_average:parseFloat(S.toFixed(2)),class_minimum:T,class_maximum:$})}).sort((a,b)=>a.subject_name.localeCompare(b.subject_name)),N&&N.length>0)K(N);else if(t.scores&&t.scores.length>0){const a=t.scores.map(b=>{const j=R.find(g=>g.id===b.subject_assignment_id),s=j?P.find(g=>g.id===j.subject_id):null,C=j?A.find(g=>g.id===j.teacher_id):null,S=M.filter(g=>{const G=R.find(le=>le.id===g.subject_assignment_id);return G&&G.subject_id===(j==null?void 0:j.subject_id)&&g.academic_year===t.academic_year&&g.term===t.term&&g.total>0}).map(g=>g.total||0),T=S.length>0?S.reduce((g,G)=>g+G,0)/S.length:0,$=S.length>0?Math.min(...S):0,x=S.length>0?Math.max(...S):0;return me(Q({},b),{subject_name:s?s.name:b.subject_name||"Unknown Subject",subject_teacher:C?`${C.firstName} ${C.lastName}`:"Not Assigned",class_average:parseFloat(T.toFixed(2)),class_minimum:$,class_maximum:x})}).sort((b,j)=>b.subject_name.localeCompare(j.subject_name));K(a)}else K(O)}catch(o){K([])}}),ye=Array.isArray(ie)?ie:[],Oe=Array.isArray(oe)?oe:[],Le=Array.isArray(U)?U:[],n=f||ye.find(i=>String(i.id)===String(t==null?void 0:t.student_id)),ee=(Ce=(Ae=(ze=t==null?void 0:t.class_id)!=null?ze:t==null?void 0:t.classId)!=null?Ae:n==null?void 0:n.class_id)!=null?Ce:n==null?void 0:n.classId,l=p||Oe.find(i=>String(i.id)===String(ee)),_e=(l==null?void 0:l.name)||"",$e=_e&&!["CRECHE","KG1","KG2","CRECHE (ONYX)","KG 1","KG 2","KINDERGARTEN 1","KINDERGARTEN 2","KG 1 (SARDIUS)","KG 1 (SARDONYX)","KG 2 (SARDIUS)","KG 2 (SARDONYX)"].includes(String(_e).toUpperCase()),Ge=(n==null?void 0:n.date_of_birth)||(n==null?void 0:n.dateOfBirth)||"",Ue=(()=>{var o,c,y;const i=(y=(c=(o=t==null?void 0:t.total_students)!=null?o:t==null?void 0:t.totalStudents)!=null?c:n==null?void 0:n.total_students)!=null?y:n==null?void 0:n.totalStudents,r=Number(i);return Number.isFinite(r)&&r>0?r:ye.filter(m=>{var A;const k=(A=m==null?void 0:m.class_id)!=null?A:m==null?void 0:m.classId;return!(ee==null||ee===""||Number(k)!==Number(ee)||String((m==null?void 0:m.status)||"").toLowerCase()==="inactive")}).length})(),je=String((l==null?void 0:l.level)||(l==null?void 0:l.section)||(l==null?void 0:l.name)||"").toLowerCase(),ce=(l==null?void 0:l.category)==="Secondary"||je.includes("jss")||je.includes("ss"),Se=ce?"PRINCIPAL":"HEAD TEACHER",He=ce?(h==null?void 0:h.principal_name)||"_________________":(h==null?void 0:h.head_teacher_name)||"_________________",Ke=ce?(h==null?void 0:h.principal_comment)||"Principal comment will appear here.":(h==null?void 0:h.head_teacher_comment)||"Head teacher comment will appear here.",ke=ce?h==null?void 0:h.principal_signature:h==null?void 0:h.head_teacher_signature,we=(n==null?void 0:n.fullName)||[n==null?void 0:n.firstName,n==null?void 0:n.otherName,n==null?void 0:n.lastName].filter(i=>String(i||"").trim()!=="").join(" ").trim(),Ve=()=>{if(t!=null&&t.class_teacher_name&&t.class_teacher_name.trim()!=="")return t.class_teacher_name;if(l!=null&&l.classTeacher)return l.classTeacher;if(l!=null&&l.classTeacherId){const i=Le.find(r=>r.id===l.classTeacherId);if(i)return`${i.firstName} ${i.lastName}`}if(l!=null&&l.id){const i=de(l.id);if(i)return`${i.firstName} ${i.lastName}`}return"_________________"},Ne=i=>i>=90?{grade:"A",remark:"Excellent"}:i>=80?{grade:"B",remark:"V. Good"}:i>=70?{grade:"C",remark:"Good"}:i>=60?{grade:"D",remark:"Satisfactory"}:i>=50?{grade:"E",remark:"Fair"}:{grade:"F",remark:"It is well"},Xe=i=>i===5?"Excellent":i===4?"Very Good":i===3?"Good":i===2?"Fair":"Poor",I=i=>i===0||i==="0"?"0":i==null||i===""?"N/A":String(i),F=i=>{const r=Number(i);return Number.isFinite(r)?Xe(r):""},B=i=>{const r={attentiveness:"Attentiveness",honesty:"Honesty",neatness:"Neatness",obedience:"Obedience",sense_of_responsibility:"Sense of Responsibility"},o={attention_to_direction:"Attention to Direction",considerate_of_others:"Considerate of Others",handwriting:"Handwriting",sports:"Sports",verbal_fluency:"Verbal Fluency",works_well_independently:"Works Well Independently"};return r[i]||o[i]||i.replace(/_/g," ").replace(/(?:^|\s)\S/g,c=>c.toUpperCase())};(v==null?void 0:v.role)==="admin"||t.print_approved;const ve=i=>{var z;const r=(i==null?void 0:i.photo_url)||(i==null?void 0:i.photoUrl)||(i==null?void 0:i.photoURL)||(i==null?void 0:i.passportPhoto)||(i==null?void 0:i.passport_photo)||(i==null?void 0:i.passport);if(!r||typeof r!="string")return[];const o=r.trim();if(!o)return[];if(/^data:image\//i.test(o)||/^https?:\/\//i.test(o))return[o];let c="";try{c=(z=he)!=null&&z.BASE_URL?new URL(he.BASE_URL).origin:""}catch(A){c=""}const y=typeof window!="undefined"?window.location.origin:"",m=o.startsWith("/")?o:`/${o.replace(/^\/+/,"")}`,k=[y?`${y}${m}`:"",c?`${c}${m}`:"",o].filter(Boolean);return Array.from(new Set(k))},Ye=(i,r)=>{const o=i.currentTarget,c=ve(r),m=Number(o.dataset.candidateIdx||"0")+1;m<c.length&&(o.dataset.candidateIdx=String(m),o.src=c[m])};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        @media print {
          @page {
            size: A4;
            margin: 10mm;
            orientation: portrait;
          }
          
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          
          body {
            margin: 0;
            padding: 0;
            font-family: 'Times New Roman', serif;
            font-size: 10pt;
            line-height: 1.2;
            width: 100%;
            height: 100vh;
            overflow: hidden;
          }
          
          .print-container {
            width: 100%;
            max-width: 190mm;
            min-height: 277mm;
            margin: 0 auto;
            box-sizing: border-box;
            overflow: hidden;
            page-break-after: always;
            page-break-inside: avoid;
            padding: 4mm;
            background: white;
          }
          
          .print-header {
            page-break-after: auto;
            page-break-inside: avoid;
          }
          
          .print-table {
            page-break-inside: avoid;
            page-break-after: auto;
          }
          
          .print-section {
            page-break-inside: avoid;
            page-break-after: auto;
          }
          
          .print-affective-psychomotor {
            page-break-inside: avoid;
            display: flex !important;
            gap: 2mm !important;
          }
          
          .print-watermark {
            position: absolute !important;
            top: 50% !important;
            left: 50% !important;
            transform: translate(-50%, -50%) !important;
            width: 140mm !important;
            height: 140mm !important;
            opacity: 0.12 !important;
            z-index: 0 !important;
            pointer-events: none !important;
            background-size: contain !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
          }
          
          .print-content {
            position: relative !important;
            z-index: 1 !important;
          }
          
          table {
            border-collapse: collapse !important;
            page-break-inside: avoid !important;
          }
          
          tr {
            page-break-inside: avoid !important;
          }
          
          td, th {
            page-break-inside: avoid !important;
          }
          
          .no-print {
            display: none !important;
          }
          
          .print-only {
            display: block !important;
          }
          
          @media screen {
            .print-only {
              display: none !important;
            }
          }
        }
      `}),e.jsx("div",{className:"print-container bg-white no-print",style:{fontFamily:'"Times New Roman", serif',width:"210mm",height:"297mm",margin:"0 auto",padding:"8mm",boxSizing:"border-box",backgroundColor:"white",overflow:"hidden",position:"relative",border:"3px double #2c3e50",boxShadow:"0 0 20px rgba(0,0,0,0.1)",background:"linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)"},children:e.jsxs("div",{className:"print-content",style:{position:"absolute",left:"-8mm",top:"-8mm",width:"210mm",height:"297mm",zIndex:1,textRendering:"geometricPrecision",fontSmooth:"always",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale",WebkitTextStroke:"0.01px transparent",textShadow:"0 0 0.01px rgba(0,0,0,0.01)",letterSpacing:"0.01px",lineHeight:"1.1",fontWeight:"500",backgroundColor:"white",padding:"8mm",boxSizing:"border-box"},children:[e.jsxs("div",{className:"print-header",style:{textAlign:"center",marginBottom:"3mm",padding:"2mm 0"},children:[e.jsx("div",{style:{marginBottom:"1mm"},children:e.jsx("img",{src:et,alt:"School Logo",style:{width:"18mm",height:"18mm",display:"block",margin:"0 auto",borderRadius:"50%",border:"2px solid #2c3e50",objectFit:"cover",backgroundColor:"#ffffff",imageRendering:"auto",WebkitImageRendering:"auto"},onError:i=>{const r=i.target;r.src="./assets/images/school-logo.jpg"}})}),e.jsx("h1",{style:{fontSize:"14pt",fontWeight:"bold",margin:"0.5mm 0",textTransform:"uppercase",color:"#2c3e50",letterSpacing:"1px",textRendering:"geometricPrecision",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale"},children:h.school_name||"SCHOOL NAME"}),e.jsx("p",{style:{fontSize:"8pt",margin:"0.3mm 0",fontStyle:"italic",color:"#555",textRendering:"geometricPrecision",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale"},children:h.school_address||"SCHOOL ADDRESS"}),e.jsx("p",{style:{fontSize:"8pt",margin:"0.3mm 0",color:"#555",textRendering:"geometricPrecision",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale"},children:h.school_email||"school@email.com"}),e.jsx("p",{style:{fontSize:"8pt",margin:"0.3mm 0",color:"#555",textRendering:"geometricPrecision",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale"},children:h.school_phone||"+234-800-000-0000"}),e.jsx("div",{style:{marginTop:"1mm",borderBottom:"2px solid #2c3e50",width:"80%",margin:"1mm auto 0"}})]}),e.jsxs("div",{className:"print-section",style:{marginBottom:"2mm",display:"flex",gap:"1mm",justifyContent:"center",alignItems:"stretch"},children:[e.jsx("div",{style:{width:"75%"},children:e.jsx("table",{style:{width:"100%",borderCollapse:"collapse",border:"2px solid #2c3e50",backgroundColor:"#f8f9fa",height:"18mm",pageBreakInside:"avoid"},children:e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt",width:"15%"},children:"Name:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",width:"35%"},children:we?we.toUpperCase():"STUDENT NAME"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt",width:"15%"},children:"Session:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",width:"35%"},children:t.academic_year||"2024/2025"})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Admission No:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:(n==null?void 0:n.admissionNumber)||"GRA/XXXXX"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Term:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:t.term||"THIRD TERM"})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Class:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:(l==null?void 0:l.name)||"CLASS NAME"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Gender:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:(n==null?void 0:n.gender)||"MALE"})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Attendance:"}),e.jsxs("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:[t.times_present||0," / ",t.total_attendance_days||0," days"]}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Total in Class:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:Ue})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Date of Birth:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:Ge}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontWeight:"bold",fontSize:"7pt"},children:"Next Term Begins:"}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt"},children:(()=>{var o;const i=String((o=t==null?void 0:t.next_term_begin)!=null?o:"").trim();return se||(i!==""&&i!=="0000-00-00"&&i!=="0000-00-00 00:00:00"?i:"")||""})()})]})]})})}),e.jsx("div",{style:{width:"25%"},children:e.jsx("div",{className:"border border-black",style:{width:"25mm",height:"30mm",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden"},children:n!=null&&n.photo_url||n!=null&&n.photoUrl?e.jsx("img",{src:ve(n)[0]||"",alt:"Student Photo",style:{width:"100%",height:"100%",objectFit:"cover",objectPosition:"center"},"data-candidate-idx":0,onError:i=>Ye(i,n)}):e.jsx("div",{style:{width:"100%",height:"100%",backgroundColor:"#f5f5f5",display:"flex",alignItems:"center",justifyContent:"center"},children:e.jsx("span",{style:{fontSize:"9pt",color:"#666"},children:"No Photo"})})})})]}),e.jsx("div",{style:{textAlign:"center",marginBottom:"1mm",padding:"1mm 0"},children:e.jsxs("h2",{style:{fontSize:"13pt",fontWeight:"bold",textDecoration:"underline",margin:"0.5mm 0",textTransform:"uppercase",color:"#2c3e50",letterSpacing:"2px",textRendering:"geometricPrecision",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale"},children:[t.term||"THIRD TERM"," RESULT SHEET"]})}),e.jsx("div",{style:{display:"flex",justifyContent:"center",marginBottom:"1mm"},children:e.jsxs("table",{className:"print-table",style:{fontSize:"7pt",width:"95%",borderCollapse:"collapse",border:"2px solid #2c3e50",backgroundColor:"white",boxShadow:"0 2px 4px rgba(0,0,0,0.1)",pageBreakInside:"avoid",pageBreakAfter:"auto",textRendering:"geometricPrecision",WebkitFontSmoothing:"antialiased",MozOsxFontSmoothing:"grayscale"},children:[e.jsx("thead",{children:e.jsxs("tr",{style:{backgroundColor:"#2c3e50",color:"white"},children:[e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"3%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"SN"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"16%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"SUBJECT"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"6%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"1st CA"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"6%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"2nd CA"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"6%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"Exams"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"6%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"Total"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"5%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"Grd"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",width:"8%",fontWeight:"bold",fontSize:"7pt",backgroundColor:"#2c3e50",color:"white"},children:"Remark"})]})}),e.jsx("tbody",{children:J&&J.length>0?J.map((i,r)=>{var c,y,m,k,z,A;const o=Ne(i.total||0);return e.jsxs("tr",{children:[e.jsx("td",{className:"border border-black text-center",style:{padding:"0.4mm",textAlign:"center",fontSize:"7pt"},children:r+1}),e.jsx("td",{className:"border border-black",style:{padding:"0.4mm",fontSize:"7pt"},children:i.subject_name||"Subject"}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.4mm",textAlign:"center",fontSize:"7pt"},children:(y=(c=i.first_ca)!=null?c:i.ca1)!=null?y:0}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.4mm",textAlign:"center",fontSize:"7pt"},children:(k=(m=i.second_ca)!=null?m:i.ca2)!=null?k:0}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.4mm",textAlign:"center",fontSize:"7pt"},children:(A=(z=i.exams)!=null?z:i.exam)!=null?A:0}),e.jsx("td",{className:"border border-black text-center font-bold",style:{padding:"0.4mm",textAlign:"center",fontWeight:"bold",fontSize:"7pt"},children:i.total||0}),e.jsx("td",{className:"border border-black text-center font-bold",style:{padding:"0.4mm",textAlign:"center",fontWeight:"bold",fontSize:"7pt"},children:o.grade}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.4mm",textAlign:"center",fontSize:"4pt"},children:o.remark})]},r)}):e.jsx("tr",{children:e.jsx("td",{colSpan:8,className:"border border-black p-2 text-center text-gray-500",style:{padding:"1.5mm",fontSize:"7pt"},children:"No scores available"})})})]})}),e.jsx("div",{style:{display:"flex",justifyContent:"center",marginBottom:"1mm"},children:e.jsx("table",{className:"print-table",style:{marginTop:"0.8mm",fontSize:"6pt",width:"95%",borderCollapse:"collapse",border:"2px solid #2c3e50",backgroundColor:"#f8f9fa",boxShadow:"0 2px 4px rgba(0,0,0,0.1)",pageBreakInside:"avoid"},children:e.jsx("tbody",{children:e.jsxs("tr",{children:[e.jsxs("td",{className:"border border-black p-1",style:{padding:"0.8mm",width:"25%",fontSize:"7pt"},children:[e.jsx("b",{children:"TOTAL:"})," ",t.total_score||"0.00"]}),e.jsxs("td",{className:"border border-black p-1",style:{padding:"0.8mm",width:"25%",fontSize:"7pt"},children:[e.jsx("b",{children:"AVG:"})," ",t.average_score||"0.00"]}),e.jsxs("td",{className:"border border-black p-1",style:{padding:"0.8mm",width:"25%",fontSize:"7pt"},children:[e.jsx("b",{children:"CLASS AVG:"})," ",t.class_average||"0.00"]}),$e?e.jsxs("td",{className:"border border-black p-1",style:{padding:"0.8mm",width:"25%",fontSize:"7pt"},children:[e.jsx("b",{children:"POS:"})," ",it(t.position)]}):e.jsxs("td",{className:"border border-black p-1",style:{padding:"0.8mm",width:"25%",fontSize:"7pt"},children:[e.jsx("b",{children:"GRADE:"})," ",Ne(Number(t.average_score||0)).grade]})]})})})}),e.jsxs("div",{style:{display:"flex",justifyContent:"center",marginTop:"2mm",marginBottom:"1.5mm",gap:"2mm"},children:[e.jsxs("div",{className:"border border-black p-1",style:{padding:"2mm",fontSize:"6pt",width:"47%",minHeight:"25mm",border:"2px solid #2c3e50",backgroundColor:"#f8f9fa",boxShadow:"0 2px 4px rgba(0,0,0,0.1)",pageBreakInside:"avoid",overflow:"visible"},children:[e.jsx("p",{style:{margin:"0.3mm 0",fontSize:"7pt",fontWeight:"bold",color:"#2c3e50"},children:"CLASS TEACHER"}),e.jsxs("p",{style:{margin:"0.3mm 0",fontSize:"7pt"},children:[e.jsx("b",{children:"Name:"})," ",Ve()]}),e.jsxs("p",{style:{margin:"0.3mm 0",fontSize:"7pt",whiteSpace:"pre-wrap",wordWrap:"break-word",maxWidth:"100%",overflow:"visible",lineHeight:"1.2"},children:[e.jsx("b",{children:"Comment:"})," ",(t==null?void 0:t.class_teacher_comment)||(t==null?void 0:t.comment)||"Teacher comment will appear here."]})]}),e.jsxs("div",{className:"border border-black p-1",style:{padding:"2mm",fontSize:"6pt",width:"47%",minHeight:"30mm",border:"2px solid #2c3e50",backgroundColor:"#f8f9fa",boxShadow:"0 2px 4px rgba(0,0,0,0.1)",pageBreakInside:"avoid",overflow:"visible"},children:[e.jsx("p",{style:{margin:"0.3mm 0",fontSize:"7pt",fontWeight:"bold",color:"#2c3e50"},children:Se}),e.jsxs("p",{style:{margin:"0.3mm 0",fontSize:"7pt"},children:[e.jsx("b",{children:"Name:"})," ",He]}),e.jsxs("p",{style:{margin:"0.3mm 0",fontSize:"7pt",whiteSpace:"pre-wrap",wordWrap:"break-word",maxWidth:"100%",overflow:"visible",lineHeight:"1.2"},children:[e.jsx("b",{children:"Comment:"})," ",Ke]}),e.jsx("div",{style:{height:"8mm",display:"flex",alignItems:"center",justifyContent:"center",position:"relative"},children:ke?e.jsx("img",{src:ke,alt:`${Se} Signature`,style:{maxWidth:"100%",maxHeight:"6mm",objectFit:"contain"}}):e.jsx("span",{style:{color:"#999",fontSize:"4pt"}})})]})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"center",gap:"2mm",marginBottom:"1mm",alignItems:"flex-start"},children:[e.jsxs("div",{style:{width:"48%"},children:[e.jsx("div",{className:"text-center mb-1",children:e.jsx("h3",{className:"font-bold underline",style:{fontSize:"10pt",marginBottom:"0.5mm",color:"#2c3e50",letterSpacing:"1px"},children:"AFFECTIVE"})}),e.jsxs("table",{style:{width:"100%",borderCollapse:"collapse",border:"1px solid black",fontSize:"6pt",boxShadow:"0 1px 2px rgba(0,0,0,0.1)",pageBreakInside:"avoid",tableLayout:"fixed"},children:[e.jsx("thead",{children:e.jsxs("tr",{style:{backgroundColor:"#1a252f",color:"white"},children:[e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",fontSize:"6pt",backgroundColor:"#1a252f",color:"white",fontWeight:"bold",width:"50%"},children:"QUALITY"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",fontSize:"6pt",backgroundColor:"#1a252f",color:"white",fontWeight:"bold",width:"20%"},children:"SCORE"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",fontSize:"6pt",backgroundColor:"#1a252f",color:"white",fontWeight:"bold",width:"30%"},children:"REMARK"})]})}),e.jsx("tbody",{children:(()=>{var r,o,c,y,m,k,z,A,R,P,M,O,a,b,j,s,C,w,S,T;const i=Fe();return e.jsxs(e.Fragment,{children:[e.jsxs("tr",{style:{backgroundColor:"#f8f9fa"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("attentiveness")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((o=i.attentiveness)!=null?o:(r=t.affective)==null?void 0:r.attentiveness)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((y=i.attentiveness)!=null?y:(c=t.affective)==null?void 0:c.attentiveness)})]}),e.jsxs("tr",{style:{backgroundColor:"white"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("honesty")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((k=i.honesty)!=null?k:(m=t.affective)==null?void 0:m.honesty)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((A=i.honesty)!=null?A:(z=t.affective)==null?void 0:z.honesty)})]}),e.jsxs("tr",{style:{backgroundColor:"#f8f9fa"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("neatness")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((P=i.neatness)!=null?P:(R=t.affective)==null?void 0:R.neatness)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((O=i.neatness)!=null?O:(M=t.affective)==null?void 0:M.neatness)})]}),e.jsxs("tr",{style:{backgroundColor:"white"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("obedience")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((b=i.obedience)!=null?b:(a=t.affective)==null?void 0:a.obedience)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((s=i.obedience)!=null?s:(j=t.affective)==null?void 0:j.obedience)})]}),e.jsxs("tr",{style:{backgroundColor:"#f8f9fa"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("sense_of_responsibility")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((w=i.sense_of_responsibility)!=null?w:(C=t.affective)==null?void 0:C.sense_of_responsibility)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((T=i.sense_of_responsibility)!=null?T:(S=t.affective)==null?void 0:S.sense_of_responsibility)})]})]})})()})]})]}),e.jsxs("div",{style:{width:"48%"},children:[e.jsx("div",{className:"text-center mb-1",children:e.jsx("h3",{className:"font-bold underline",style:{fontSize:"10pt",marginBottom:"0.5mm",color:"#2c3e50",letterSpacing:"1px"},children:"PSYCHOMOTOR"})}),e.jsxs("table",{style:{width:"100%",borderCollapse:"collapse",border:"1px solid black",fontSize:"7pt",boxShadow:"0 1px 2px rgba(0,0,0,0.1)",pageBreakInside:"avoid",tableLayout:"fixed"},children:[e.jsx("thead",{children:e.jsxs("tr",{style:{backgroundColor:"#1a252f",color:"white"},children:[e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",fontSize:"6pt",backgroundColor:"#1a252f",color:"white",fontWeight:"bold",width:"50%"},children:"SKILL"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",fontSize:"6pt",backgroundColor:"#1a252f",color:"white",fontWeight:"bold",width:"20%"},children:"SCORE"}),e.jsx("th",{className:"border border-black",style:{padding:"0.6mm",fontSize:"6pt",backgroundColor:"#1a252f",color:"white",fontWeight:"bold",width:"30%"},children:"REMARK"})]})}),e.jsx("tbody",{children:(()=>{var r,o,c,y,m,k,z,A,R,P,M,O,a,b,j,s,C,w,S,T,$,x,g,G,le,Re,We,ue;const i=Be();return e.jsxs(e.Fragment,{children:[e.jsxs("tr",{style:{backgroundColor:"#f8f9fa"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("attention_to_direction")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((o=i.attention_to_direction)!=null?o:(r=t.psychomotor)==null?void 0:r.attention_to_direction)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((y=i.attention_to_direction)!=null?y:(c=t.psychomotor)==null?void 0:c.attention_to_direction)})]}),e.jsxs("tr",{style:{backgroundColor:"white"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("considerate_of_others")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((k=i.considerate_of_others)!=null?k:(m=t.psychomotor)==null?void 0:m.considerate_of_others)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((A=i.considerate_of_others)!=null?A:(z=t.psychomotor)==null?void 0:z.considerate_of_others)})]}),e.jsxs("tr",{style:{backgroundColor:"#f8f9fa"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("handwriting")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((P=i.handwriting)!=null?P:(R=t.psychomotor)==null?void 0:R.handwriting)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((O=i.handwriting)!=null?O:(M=t.psychomotor)==null?void 0:M.handwriting)})]}),e.jsxs("tr",{style:{backgroundColor:"white"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("sports")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((b=i.sports)!=null?b:(a=t.psychomotor)==null?void 0:a.sports)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((s=i.sports)!=null?s:(j=t.psychomotor)==null?void 0:j.sports)})]}),e.jsxs("tr",{style:{backgroundColor:"#f8f9fa"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("verbal_fluency")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((w=i.verbal_fluency)!=null?w:(C=t.psychomotor)==null?void 0:C.verbal_fluency)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((T=i.verbal_fluency)!=null?T:(S=t.psychomotor)==null?void 0:S.verbal_fluency)})]}),e.jsxs("tr",{style:{backgroundColor:"white"},children:[e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"600",color:"#000000",textRendering:"geometricPrecision"},children:B("works_well_independently")}),e.jsx("td",{className:"border border-black text-center",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"bold",color:"#000000",textRendering:"geometricPrecision"},children:I((G=(x=i.works_well_independently)!=null?x:($=t==null?void 0:t.psychomotor)==null?void 0:$.works_well_independently)!=null?G:(g=t==null?void 0:t.psychomotor)==null?void 0:g.independent_work)}),e.jsx("td",{className:"border border-black",style:{padding:"0.5mm",fontSize:"7pt",fontWeight:"500",color:"#000000",textRendering:"geometricPrecision"},children:F((ue=(Re=i.works_well_independently)!=null?Re:(le=t==null?void 0:t.psychomotor)==null?void 0:le.works_well_independently)!=null?ue:(We=t==null?void 0:t.psychomotor)==null?void 0:We.independent_work)})]})]})})()})]})]})]})]})}),W&&e.jsxs("div",{className:"no-print",style:{textAlign:"center",marginTop:"20px",marginBottom:"20px",padding:"10px"},children:[e.jsx(xe,{onClick:V,className:"bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded",style:{marginRight:"8px"},children:"Print Result (Ctrl+P)"}),u&&e.jsx(xe,{onClick:()=>u(t.id),className:"bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded",children:"Download PDF"})]})]})}function lt({studentId:f,resultId:p,onClose:t}){const{students:N,classes:W,compiledResults:u}=Ee(),[_,X]=L.useState(null),[v,h]=L.useState(null),[Z,ie]=L.useState(null),oe=(_==null?void 0:_.fullName)||[_==null?void 0:_.firstName,_==null?void 0:_.otherName,_==null?void 0:_.lastName].filter(U=>String(U||"").trim()!=="").join(" ").trim();return L.useEffect(()=>{var ne,re,ae,de,be,fe,J,K,se,D;const U=Array.isArray(N)?N:[],Y=Array.isArray(u)?u:[],q=Array.isArray(W)?W:[],d=Y.find(V=>String(V.id)===String(p)),E=U.find(V=>String(V.id)===String(f)),H=d?{id:(ne=d==null?void 0:d.student_id)!=null?ne:f,firstName:(ae=(re=d==null?void 0:d.first_name)!=null?re:d==null?void 0:d.student_first_name)!=null?ae:"",otherName:"",lastName:(be=(de=d==null?void 0:d.last_name)!=null?de:d==null?void 0:d.student_last_name)!=null?be:"",admissionNumber:(fe=d==null?void 0:d.admission_number)!=null?fe:"",class_id:d==null?void 0:d.class_id}:null,pe=(D=(se=(K=(J=d==null?void 0:d.class_id)!=null?J:d==null?void 0:d.classId)!=null?K:E==null?void 0:E.class_id)!=null?se:E==null?void 0:E.classId)!=null?D:H==null?void 0:H.class_id,ge=q.find(V=>String(V.id)===String(pe));X(E||H),h(d),ie(ge)},[f,p,N,u,W]),!_||!v?e.jsx("div",{className:"min-h-screen bg-gray-100 flex items-center justify-center",children:e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"}),e.jsx("p",{className:"text-gray-600",children:"Loading result..."})]})}):e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        @media screen {
          body {
            margin: 0;
            padding: 0;
            overflow-x: auto;
            background: #f3f4f6;
          }
          
          .full-page-container {
            background: #f3f4f6;
            min-height: 100vh;
            padding: 2rem 0;
          }
          
          .no-print {
            display: block !important;
          }
          
          .print-only {
            display: none !important;
          }
        }
        
        @media print {
          body {
            margin: 0;
            padding: 0;
            background: white !important;
            overflow: visible !important;
          }
          
          .full-page-container {
            background: white !important;
            padding: 0 !important;
          }
          
          .no-print {
            display: none !important;
          }
          
          .print-only {
            display: block !important;
          }
          
          .full-page-container {
            background: white !important;
            box-shadow: none !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          
          .bg-white.shadow-2xl.mx-auto {
            box-shadow: none !important;
            margin: 0 !important;
            max-width: 100% !important;
          }
        }
      `}),e.jsxs("div",{className:"min-h-screen bg-gray-100",children:[e.jsx("div",{className:"no-print bg-white shadow-md border-b border-gray-200 sticky top-0 z-50",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsx("div",{className:"flex justify-between items-center py-4",children:e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsxs(xe,{variant:"outline",onClick:t,className:"flex items-center gap-2",children:[e.jsx(tt,{className:"w-4 h-4"}),"Back to Results"]}),e.jsxs("div",{children:[e.jsxs("h1",{className:"text-xl font-semibold text-gray-900",children:[oe," - Result Sheet"]}),e.jsxs("p",{className:"text-sm text-gray-600",children:[Z==null?void 0:Z.name," • ",v.term," • ",v.academic_year]})]})]})})})}),e.jsx("div",{className:"full-page-container py-8",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsx("div",{className:"bg-white shadow-2xl mx-auto overflow-auto",style:{width:"210mm",minHeight:"297mm",maxWidth:"100%",aspectRatio:"210/297",overflow:"visible"},children:e.jsx("div",{className:"transform-gpu",style:{transform:"scale(1)",transformOrigin:"top center",width:"100%",height:"100%",overflow:"visible"},children:e.jsx(rt,{student:_,studentClass:Z,result:v,showActions:!1,currentUser:{role:"admin"}})})})})})]})]})}export{lt as F,rt as S,it as f};
